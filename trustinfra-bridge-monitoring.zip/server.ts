import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";

const db = new Database("trustinfra.db");

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE,
    password TEXT,
    role TEXT
  );

  CREATE TABLE IF NOT EXISTS construction_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    cement_amount REAL,
    sand_amount REAL,
    distance_covered REAL,
    moisture_level REAL,
    humidity REAL,
    ultrasonic_score REAL,
    iot_moisture REAL,
    iot_humidity REAL,
    iot_ultrasonic REAL,
    notes TEXT,
    user_id INTEGER,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );
`);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Auth Routes
  app.post("/api/auth/signup", (req, res) => {
    const { email, password, role } = req.body;
    try {
      const stmt = db.prepare("INSERT INTO users (email, password, role) VALUES (?, ?, ?)");
      const info = stmt.run(email, password, role); // In a real app, hash the password
      res.json({ id: info.lastInsertRowid, email, role });
    } catch (error) {
      res.status(400).json({ error: "Email already exists" });
    }
  });

  app.post("/api/auth/login", (req, res) => {
    const { email, password } = req.body;
    const user = db.prepare("SELECT * FROM users WHERE email = ? AND password = ?").get(email, password);
    if (user) {
      res.json({ id: user.id, email: user.email, role: user.role });
    } else {
      res.status(401).json({ error: "Invalid credentials" });
    }
  });

  // API Routes
  app.get("/api/logs", (req, res) => {
    try {
      const logs = db.prepare("SELECT * FROM construction_logs ORDER BY timestamp DESC").all();
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch logs" });
    }
  });

  app.post("/api/logs", (req, res) => {
    const {
      cement_amount,
      sand_amount,
      distance_covered,
      moisture_level,
      humidity,
      ultrasonic_score,
      iot_moisture,
      iot_humidity,
      iot_ultrasonic,
      notes
    } = req.body;

    try {
      const stmt = db.prepare(`
        INSERT INTO construction_logs (
          cement_amount, sand_amount, distance_covered, moisture_level, 
          humidity, ultrasonic_score, iot_moisture, iot_humidity, 
          iot_ultrasonic, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      const info = stmt.run(
        cement_amount, sand_amount, distance_covered, moisture_level,
        humidity, ultrasonic_score, iot_moisture, iot_humidity,
        iot_ultrasonic, notes
      );
      res.json({ id: info.lastInsertRowid });
    } catch (error) {
      res.status(500).json({ error: "Failed to save log" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(process.cwd(), "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(process.cwd(), "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
