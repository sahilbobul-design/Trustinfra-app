import { GoogleGenAI, Type } from "@google/genai";
import { ConstructionLog } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function analyzeConstructionQuality(log: ConstructionLog) {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Analyze this bridge construction log. Compare manual inputs with IoT sensor data.
    
    Manual Data:
    - Moisture: ${log.moisture_level}%
    - Humidity: ${log.humidity}%
    - Ultrasonic Score: ${log.ultrasonic_score}
    
    IoT Data:
    - Moisture: ${log.iot_moisture}%
    - Humidity: ${log.iot_humidity}%
    - Ultrasonic Score: ${log.iot_ultrasonic}
    
    Other Details:
    - Cement: ${log.cement_amount} units
    - Sand: ${log.sand_amount} units
    - Distance Covered: ${log.distance_covered}m
    - Notes: ${log.notes}
    
    Provide a quality assessment score (0-100) and detailed feedback.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          score: { type: Type.NUMBER },
          status: { type: Type.STRING, description: "optimal, warning, or critical" },
          summary: { type: Type.STRING },
          discrepancies: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING } 
          },
          recommendations: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING } 
          }
        },
        required: ["score", "status", "summary", "discrepancies", "recommendations"]
      }
    }
  });

  return JSON.parse(response.text);
}
