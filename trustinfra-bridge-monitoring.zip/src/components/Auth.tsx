import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Activity, Mail, Lock, UserCircle, Shield, HardHat, Landmark } from 'lucide-react';
import { Role, User } from '../types';
import { cn } from '../lib/utils';

interface AuthProps {
  onLogin: (user: User) => void;
}

export default function Auth({ onLogin }: AuthProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<Role>('engineer');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const endpoint = isLogin ? '/api/auth/login' : '/api/auth/signup';
    const body = isLogin ? { email, password } : { email, password, role };

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      const data = await res.json();

      if (res.ok) {
        onLogin(data);
      } else {
        setError(data.error || 'Authentication failed');
      }
    } catch (err) {
      setError('Connection error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-bg">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-bg border border-line p-8 shadow-2xl"
      >
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <Activity className="w-12 h-12" />
          </div>
          <h1 className="text-3xl font-bold tracking-tighter">TRUSTINFRA</h1>
          <p className="font-serif italic opacity-60">Bridge Monitoring System</p>
        </div>

        <div className="flex border-b border-line mb-8">
          <button 
            onClick={() => setIsLogin(true)}
            className={cn(
              "flex-1 py-2 text-sm font-mono uppercase tracking-widest transition-colors",
              isLogin ? "bg-ink text-bg" : "hover:bg-ink/5"
            )}
          >
            Login
          </button>
          <button 
            onClick={() => setIsLogin(false)}
            className={cn(
              "flex-1 py-2 text-sm font-mono uppercase tracking-widest transition-colors",
              !isLogin ? "bg-ink text-bg" : "hover:bg-ink/5"
            )}
          >
            Signup
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <div className="p-3 bg-red-500/10 border border-red-500/50 text-red-600 text-xs font-mono">
              ERROR: {error.toUpperCase()}
            </div>
          )}

          <div className="space-y-1">
            <label className="text-[10px] font-mono uppercase tracking-widest opacity-50 block">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 opacity-40" />
              <input 
                type="email" 
                required
                className="w-full bg-transparent border border-line p-2 pl-10 text-sm focus:outline-none focus:border-ink transition-colors"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-mono uppercase tracking-widest opacity-50 block">Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 opacity-40" />
              <input 
                type="password" 
                required
                className="w-full bg-transparent border border-line p-2 pl-10 text-sm focus:outline-none focus:border-ink transition-colors"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>

          {!isLogin && (
            <div className="space-y-3">
              <label className="text-[10px] font-mono uppercase tracking-widest opacity-50 block">Select Role</label>
              <div className="grid grid-cols-3 gap-2">
                <RoleButton 
                  active={role === 'admin'} 
                  onClick={() => setRole('admin')} 
                  icon={<Shield className="w-4 h-4" />} 
                  label="Admin" 
                />
                <RoleButton 
                  active={role === 'engineer'} 
                  onClick={() => setRole('engineer')} 
                  icon={<HardHat className="w-4 h-4" />} 
                  label="Engineer" 
                />
                <RoleButton 
                  active={role === 'govt'} 
                  onClick={() => setRole('govt')} 
                  icon={<Landmark className="w-4 h-4" />} 
                  label="Govt" 
                />
              </div>
            </div>
          )}

          <button 
            type="submit"
            disabled={loading}
            className="w-full bg-ink text-bg py-3 text-sm font-mono uppercase tracking-widest hover:opacity-90 transition-opacity disabled:opacity-50"
          >
            {loading ? 'Processing...' : (isLogin ? 'Enter System' : 'Create Account')}
          </button>
        </form>

        <div className="mt-8 pt-8 border-t border-line text-center">
          <p className="text-[10px] font-mono opacity-40 uppercase tracking-widest">
            Secure Infrastructure Monitoring Protocol v2.4
          </p>
        </div>
      </motion.div>
    </div>
  );
}

function RoleButton({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex flex-col items-center justify-center p-3 border border-line transition-all gap-2",
        active ? "bg-ink text-bg border-ink" : "hover:border-ink/50 opacity-60"
      )}
    >
      {icon}
      <span className="text-[10px] font-mono uppercase tracking-tighter">{label}</span>
    </button>
  );
}
