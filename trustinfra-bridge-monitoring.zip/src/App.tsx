import React, { useState, useEffect } from 'react';
import { 
  Activity, 
  Database, 
  AlertTriangle, 
  CheckCircle2, 
  Plus, 
  History, 
  TrendingUp,
  Cpu,
  Droplets,
  Wind,
  Zap,
  ChevronRight,
  Info
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import { ConstructionLog, AnalysisResult, User } from './types';
import { analyzeConstructionQuality } from './services/geminiService';
import { cn } from './lib/utils';
import Auth from './components/Auth';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [logs, setLogs] = useState<ConstructionLog[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [selectedLog, setSelectedLog] = useState<ConstructionLog | null>(null);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const [formData, setFormData] = useState({
    cement_amount: '',
    sand_amount: '',
    distance_covered: '',
    moisture_level: '',
    humidity: '',
    ultrasonic_score: '',
    iot_moisture: '',
    iot_humidity: '',
    iot_ultrasonic: '',
    notes: ''
  });

  useEffect(() => {
    if (user) {
      fetchLogs();
    }
  }, [user]);

  const fetchLogs = async () => {
    const res = await fetch('/api/logs');
    const data = await res.json();
    setLogs(data);
  };

  const handleLogout = () => {
    setUser(null);
    setLogs([]);
    setSelectedLog(null);
    setAnalysis(null);
  };

  if (!user) {
    return <Auth onLogin={setUser} />;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/logs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...formData,
        user_id: user.id,
        cement_amount: Number(formData.cement_amount),
        sand_amount: Number(formData.sand_amount),
        distance_covered: Number(formData.distance_covered),
        moisture_level: Number(formData.moisture_level),
        humidity: Number(formData.humidity),
        ultrasonic_score: Number(formData.ultrasonic_score),
        iot_moisture: Number(formData.iot_moisture),
        iot_humidity: Number(formData.iot_humidity),
        iot_ultrasonic: Number(formData.iot_ultrasonic),
      })
    });
    if (res.ok) {
      setIsAdding(false);
      fetchLogs();
      setFormData({
        cement_amount: '',
        sand_amount: '',
        distance_covered: '',
        moisture_level: '',
        humidity: '',
        ultrasonic_score: '',
        iot_moisture: '',
        iot_humidity: '',
        iot_ultrasonic: '',
        notes: ''
      });
    }
  };

  const handleAnalyze = async (log: ConstructionLog) => {
    setSelectedLog(log);
    setIsAnalyzing(true);
    setAnalysis(null);
    try {
      const result = await analyzeConstructionQuality(log);
      setAnalysis(result);
    } catch (error) {
      console.error(error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="border-b border-line p-6 flex justify-between items-center bg-bg sticky top-0 z-10">
        <div className="flex items-center gap-8">
          <div>
            <h1 className="text-2xl font-bold tracking-tighter flex items-center gap-2">
              <Activity className="w-6 h-6" />
              TRUSTINFRA <span className="font-serif italic font-normal text-lg opacity-60">Bridge Monitoring</span>
            </h1>
            <p className="text-[10px] font-mono uppercase tracking-widest opacity-50 mt-1">
              System Status: Operational // User: {user.email} // Role: {user.role}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setIsAdding(true)}
            className="bg-ink text-bg px-4 py-2 rounded-none flex items-center gap-2 hover:opacity-90 transition-opacity text-sm font-medium"
          >
            <Plus className="w-4 h-4" />
            NEW LOG ENTRY
          </button>
          <button 
            onClick={handleLogout}
            className="border border-line px-4 py-2 text-sm font-mono uppercase tracking-widest hover:bg-ink hover:text-bg transition-colors"
          >
            Logout
          </button>
        </div>
      </header>

      <main className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
        {/* Left Sidebar: Logs List */}
        <div className="lg:col-span-4 border-r border-line overflow-y-auto max-h-[calc(100vh-88px)]">
          <div className="p-4 border-b border-line flex items-center justify-between bg-bg/50 backdrop-blur">
            <h2 className="col-header">Construction History</h2>
            <History className="w-4 h-4 opacity-40" />
          </div>
          <div className="divide-y divide-line">
            {logs.map((log) => (
              <button
                key={log.id}
                onClick={() => handleAnalyze(log)}
                className={cn(
                  "w-full text-left p-4 hover:bg-ink hover:text-bg transition-colors group",
                  selectedLog?.id === log.id && "bg-ink text-bg"
                )}
              >
                <div className="flex justify-between items-start mb-2">
                  <span className="data-value text-xs opacity-60">
                    {new Date(log.timestamp).toLocaleString()}
                  </span>
                  <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <div className="flex justify-between items-end">
                  <div>
                    <p className="font-medium text-sm">Distance: {log.distance_covered}m</p>
                    <p className="text-[10px] opacity-60 uppercase tracking-wider">Log ID: #{log.id.toString().padStart(4, '0')}</p>
                  </div>
                  <div className="text-right">
                    <p className="data-value text-xs">{log.ultrasonic_score.toFixed(1)} US</p>
                    <p className="text-[10px] opacity-60 uppercase tracking-wider">Ultrasonic</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Main Content: Dashboard & Analysis */}
        <div className="lg:col-span-8 overflow-y-auto max-h-[calc(100vh-88px)] p-8">
          {selectedLog ? (
            <div className="space-y-8">
              {/* Analysis Header */}
              <div className="flex justify-between items-start border-b border-line pb-6">
                <div>
                  <h2 className="text-3xl font-bold tracking-tighter mb-2">
                    LOG ANALYSIS <span className="font-serif italic font-normal text-xl opacity-50">#{selectedLog.id.toString().padStart(4, '0')}</span>
                  </h2>
                  <p className="text-sm opacity-60 max-w-md">
                    Comparing manual construction logs with real-time IoT sensor data to verify structural integrity.
                  </p>
                </div>
                {analysis && (
                  <div className="text-right">
                    <div className={cn(
                      "text-5xl font-bold tracking-tighter",
                      analysis.status === 'optimal' ? "text-emerald-600" : 
                      analysis.status === 'warning' ? "text-amber-600" : "text-red-600"
                    )}>
                      {analysis.score}%
                    </div>
                    <p className="text-[10px] font-mono uppercase tracking-widest opacity-50">Integrity Score</p>
                  </div>
                )}
              </div>

              {/* Data Comparison Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <ComparisonCard 
                  title="Moisture Level" 
                  manual={selectedLog.moisture_level} 
                  iot={selectedLog.iot_moisture} 
                  unit="%" 
                  icon={<Droplets className="w-4 h-4" />}
                />
                <ComparisonCard 
                  title="Humidity" 
                  manual={selectedLog.humidity} 
                  iot={selectedLog.iot_humidity} 
                  unit="%" 
                  icon={<Wind className="w-4 h-4" />}
                />
                <ComparisonCard 
                  title="Ultrasonic Score" 
                  manual={selectedLog.ultrasonic_score} 
                  iot={selectedLog.iot_ultrasonic} 
                  unit="US" 
                  icon={<Zap className="w-4 h-4" />}
                />
              </div>

              {/* AI Insights */}
              <div className="border border-line p-6 bg-white/50">
                <div className="flex items-center gap-2 mb-4">
                  <Cpu className="w-5 h-5" />
                  <h3 className="col-header">AI Structural Integrity Report</h3>
                </div>
                
                {isAnalyzing ? (
                  <div className="py-12 flex flex-col items-center justify-center space-y-4">
                    <div className="w-8 h-8 border-2 border-ink border-t-transparent rounded-full animate-spin" />
                    <p className="text-xs font-mono animate-pulse">ANALYZING DATA STREAMS...</p>
                  </div>
                ) : analysis ? (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                  >
                    <p className="text-lg leading-relaxed font-medium">
                      {analysis.summary}
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div>
                        <h4 className="text-[10px] font-mono uppercase tracking-widest opacity-50 mb-3 flex items-center gap-2">
                          <AlertTriangle className="w-3 h-3" /> Discrepancies Detected
                        </h4>
                        <ul className="space-y-2">
                          {analysis.discrepancies.map((d, i) => (
                            <li key={i} className="text-sm flex gap-2">
                              <span className="opacity-30">—</span> {d}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h4 className="text-[10px] font-mono uppercase tracking-widest opacity-50 mb-3 flex items-center gap-2">
                          <CheckCircle2 className="w-3 h-3" /> Recommendations
                        </h4>
                        <ul className="space-y-2">
                          {analysis.recommendations.map((r, i) => (
                            <li key={i} className="text-sm flex gap-2">
                              <span className="opacity-30">—</span> {r}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </motion.div>
                ) : (
                  <div className="py-12 text-center">
                    <button 
                      onClick={() => handleAnalyze(selectedLog)}
                      className="border border-line px-6 py-3 hover:bg-ink hover:text-bg transition-colors text-sm font-medium"
                    >
                      GENERATE INTEGRITY REPORT
                    </button>
                  </div>
                )}
              </div>

              {/* Material Usage & Trends */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="border border-line p-6">
                  <h3 className="col-header mb-6">Material Consumption</h3>
                  <div className="space-y-4">
                    <MaterialBar label="Cement" value={selectedLog.cement_amount} max={1000} unit="units" />
                    <MaterialBar label="Sand" value={selectedLog.sand_amount} max={2000} unit="units" />
                  </div>
                </div>
                <div className="border border-line p-6">
                  <h3 className="col-header mb-6">Construction Velocity</h3>
                  <div className="h-32">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={logs.slice().reverse()}>
                        <defs>
                          <linearGradient id="colorDist" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#141414" stopOpacity={0.1}/>
                            <stop offset="95%" stopColor="#141414" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <Area type="monotone" dataKey="distance_covered" stroke="#141414" fillOpacity={1} fill="url(#colorDist)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                  <p className="text-[10px] font-mono text-center mt-2 opacity-50">DISTANCE COVERED OVER TIME (M)</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-40">
              <Database className="w-12 h-12" />
              <div>
                <p className="text-lg font-medium">No Log Selected</p>
                <p className="text-sm">Select a construction log from the sidebar to view analysis.</p>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Add Log Modal */}
      <AnimatePresence>
        {isAdding && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAdding(false)}
              className="absolute inset-0 bg-ink/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-bg border border-line w-full max-w-2xl overflow-hidden shadow-2xl"
            >
              <div className="p-6 border-b border-line flex justify-between items-center">
                <h2 className="text-xl font-bold tracking-tighter">NEW CONSTRUCTION LOG</h2>
                <button onClick={() => setIsAdding(false)} className="opacity-50 hover:opacity-100">✕</button>
              </div>
              <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Manual Inputs */}
                  <div className="space-y-4">
                    <h3 className="col-header border-b border-line pb-2">Manual Field Data</h3>
                    <InputField label="Cement Amount (Units)" value={formData.cement_amount} onChange={(v) => setFormData({...formData, cement_amount: v})} />
                    <InputField label="Sand Amount (Units)" value={formData.sand_amount} onChange={(v) => setFormData({...formData, sand_amount: v})} />
                    <InputField label="Distance Covered (m)" value={formData.distance_covered} onChange={(v) => setFormData({...formData, distance_covered: v})} />
                    <InputField label="Moisture Level (%)" value={formData.moisture_level} onChange={(v) => setFormData({...formData, moisture_level: v})} />
                    <InputField label="Humidity (%)" value={formData.humidity} onChange={(v) => setFormData({...formData, humidity: v})} />
                    <InputField label="Ultrasonic Score" value={formData.ultrasonic_score} onChange={(v) => setFormData({...formData, ultrasonic_score: v})} />
                  </div>
                  {/* IoT Inputs */}
                  <div className="space-y-4">
                    <h3 className="col-header border-b border-line pb-2">IoT Sensor Data</h3>
                    <InputField label="IoT Moisture (%)" value={formData.iot_moisture} onChange={(v) => setFormData({...formData, iot_moisture: v})} />
                    <InputField label="IoT Humidity (%)" value={formData.iot_humidity} onChange={(v) => setFormData({...formData, iot_humidity: v})} />
                    <InputField label="IoT Ultrasonic Score" value={formData.iot_ultrasonic} onChange={(v) => setFormData({...formData, iot_ultrasonic: v})} />
                    <div className="pt-4">
                      <label className="text-[10px] font-mono uppercase tracking-widest opacity-50 block mb-1">Additional Notes</label>
                      <textarea 
                        className="w-full bg-transparent border border-line p-2 text-sm focus:outline-none min-h-[100px]"
                        value={formData.notes}
                        onChange={(e) => setFormData({...formData, notes: e.target.value})}
                      />
                    </div>
                  </div>
                </div>
                <div className="pt-4 flex justify-end gap-4">
                  <button 
                    type="button"
                    onClick={() => setIsAdding(false)}
                    className="px-6 py-2 text-sm font-medium opacity-50 hover:opacity-100"
                  >
                    CANCEL
                  </button>
                  <button 
                    type="submit"
                    className="bg-ink text-bg px-8 py-2 text-sm font-medium hover:opacity-90 transition-opacity"
                  >
                    SAVE LOG ENTRY
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ComparisonCard({ title, manual, iot, unit, icon }: { title: string, manual: number, iot: number, unit: string, icon: React.ReactNode }) {
  const diff = Math.abs(manual - iot);
  const isWarning = diff > (manual * 0.1); // 10% tolerance

  return (
    <div className="border border-line p-4 space-y-4">
      <div className="flex items-center justify-between">
        <h4 className="col-header flex items-center gap-2">{icon} {title}</h4>
        {isWarning && <AlertTriangle className="w-4 h-4 text-amber-600" />}
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <p className="data-value text-xl">{manual}{unit}</p>
          <p className="text-[10px] opacity-50 uppercase tracking-widest">Manual</p>
        </div>
        <div className="border-l border-line pl-4">
          <p className="data-value text-xl">{iot}{unit}</p>
          <p className="text-[10px] opacity-50 uppercase tracking-widest">IoT Sensor</p>
        </div>
      </div>
      <div className="pt-2 border-t border-line/10">
        <p className="text-[10px] font-mono opacity-40">VARIANCE: {((diff / manual) * 100).toFixed(1)}%</p>
      </div>
    </div>
  );
}

function MaterialBar({ label, value, max, unit }: { label: string, value: number, max: number, unit: string }) {
  const percentage = Math.min((value / max) * 100, 100);
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-xs">
        <span className="font-medium">{label}</span>
        <span className="data-value">{value} / {max} {unit}</span>
      </div>
      <div className="h-2 bg-ink/5 border border-line/10">
        <div 
          className="h-full bg-ink transition-all duration-1000" 
          style={{ width: `${percentage}%` }} 
        />
      </div>
    </div>
  );
}

function InputField({ label, value, onChange }: { label: string, value: string, onChange: (v: string) => void }) {
  return (
    <div>
      <label className="text-[10px] font-mono uppercase tracking-widest opacity-50 block mb-1">{label}</label>
      <input 
        type="number"
        step="0.1"
        className="w-full bg-transparent border border-line p-2 text-sm focus:outline-none focus:border-ink transition-colors data-value"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required
      />
    </div>
  );
}
