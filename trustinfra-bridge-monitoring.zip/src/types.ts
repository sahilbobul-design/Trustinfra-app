export type Role = 'admin' | 'engineer' | 'govt';

export interface User {
  id: number;
  email: string;
  role: Role;
}

export interface ConstructionLog {
  id: number;
  timestamp: string;
  cement_amount: number;
  sand_amount: number;
  distance_covered: number;
  moisture_level: number;
  humidity: number;
  ultrasonic_score: number;
  iot_moisture: number;
  iot_humidity: number;
  iot_ultrasonic: number;
  notes: string;
}

export interface AnalysisResult {
  score: number;
  status: 'optimal' | 'warning' | 'critical';
  summary: string;
  discrepancies: string[];
  recommendations: string[];
}
